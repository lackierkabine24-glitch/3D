Static assets can be added here.
