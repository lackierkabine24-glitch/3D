# POWCEQ 3D Oven Configurator

Astro + Three.js proof-of-concept powder-coating curing oven configurator. Uses procedural 3D geometry, so **no external models or textures are required**.

## Run

```bash
npm install
npm run dev
```

Open the URL shown by Astro (usually port 4321). In GitHub Codespaces, open the forwarded port.

## Structure

- `src/pages/index.astro` — main page
- `src/components/OvenConfigurator.astro` — interactive 3D configurator
- `public/` — optional future static assets

## Features

Width, height, depth, heating type, finish, animated double doors, orbit/zoom, JSON export, quotation email.

## Note

This is a recreated standalone working prototype, **not a byte-for-byte copy of the original ZIP**. It does not include engineering CAD files or manufacturing drawings. Review configurations before commercial use.
